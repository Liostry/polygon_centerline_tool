from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (QgsProcessing,
                       QgsFeatureSink,
                       QgsProcessingException,
                       QgsProcessingAlgorithm,
                       QgsProcessingParameterFeatureSource,
                       QgsProcessingParameterFeatureSink,
                       QgsProcessingParameterNumber,
                       QgsProcessingParameterBoolean,
                       QgsProcessingParameterEnum,
                       QgsWkbTypes,
                       QgsFeature,
                       QgsGeometry,
                       QgsFields,
                       QgsField)
from qgis import processing
import numpy as np
from scipy.spatial import Voronoi
from shapely.geometry import (Polygon, MultiPolygon, LineString, 
                              MultiLineString, Point, mapping)
from shapely.ops import linemerge, unary_union, polygonize
from shapely import wkt
from PyQt5.QtCore import QVariant

class PolygonCenterlineAlgorithm(QgsProcessingAlgorithm):
    INPUT = 'INPUT'
    OUTPUT = 'OUTPUT'
    DENSITY = 'DENSITY'
    SIMPLIFY = 'SIMPLIFY_TOLERANCE'
    CONNECT_FEATURES = 'CONNECT_FEATURES'
    SPLIT_AT_JUNCTIONS = 'SPLIT_AT_JUNCTIONS'

    def tr(self, string):
        return QCoreApplication.translate('Processing', string)

    def createInstance(self):
        return PolygonCenterlineAlgorithm()

    def name(self):
        return 'polygontocenterline'

    def displayName(self):
        return self.tr('Polygon to Centerline')

    def group(self):
        return self.tr('Vector geometry')

    def groupId(self):
        return 'vectorgeometry'

    def shortHelpString(self):
        return self.tr("""
        Создает центральные линии из полигональных объектов методом диаграммы Вороного.
        
        Алгоритм:
        1. Дискретизация границы полигона с заданной плотностью
        2. Построение диаграммы Вороного
        3. Фильтрация ребер внутри полигона
        4. Объединение в связные линии
        
        Параметры:
        - Плотность точек: меньше = точнее, но медленнее (рекомендуется 0.5-2м для городских данных)
        - Упрощение: порог Douglas-Peucker для сглаживания результата
        - Соединение касающихся объектов: автоматическое обнаружение топологии
        - Разделение на сегменты: разбивать линии в точках пересечения
        
        Основано на алгоритмах HCMGIS и ArcGIS Polygon To Centerline.
        """)

    def initAlgorithm(self, config=None):
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT,
                self.tr('Входные полигоны'),
                [QgsProcessing.TypeVectorPolygon]
            )
        )

        self.addParameter(
            QgsProcessingParameterNumber(
                self.DENSITY,
                self.tr('Плотность дискретизации границы (метры)'),
                type=QgsProcessingParameterNumber.Double,
                defaultValue=1.0,
                minValue=0.01,
                maxValue=100.0
            )
        )

        self.addParameter(
            QgsProcessingParameterNumber(
                self.SIMPLIFY,
                self.tr('Допуск упрощения (0 = без упрощения)'),
                type=QgsProcessingParameterNumber.Double,
                defaultValue=0.1,
                minValue=0.0,
                maxValue=10.0
            )
        )

        self.addParameter(
            QgsProcessingParameterBoolean(
                self.CONNECT_FEATURES,
                self.tr('Соединять касающиеся полигоны'),
                defaultValue=True
            )
        )

        self.addParameter(
            QgsProcessingParameterBoolean(
                self.SPLIT_AT_JUNCTIONS,
                self.tr('Разделять на сегменты в точках пересечения'),
                defaultValue=True
            )
        )

        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                self.tr('Центральные линии')
            )
        )

    def densify_boundary(self, polygon, density):
        """Дискретизация границы полигона с заданной плотностью"""
        coords = []
        boundary = polygon.boundary
        
        if boundary.geom_type == 'LineString':
            lines = [boundary]
        else:
            lines = list(boundary.geoms)
        
        for line in lines:
            line_coords = list(line.coords)
            for i in range(len(line_coords) - 1):
                p1 = np.array(line_coords[i])
                p2 = np.array(line_coords[i + 1])
                dist = np.linalg.norm(p2 - p1)
                
                if dist > density:
                    num_points = int(np.ceil(dist / density))
                    for j in range(num_points):
                        t = j / num_points
                        point = p1 + t * (p2 - p1)
                        coords.append(tuple(point))
                else:
                    coords.append(tuple(p1))
            
            # Добавляем последнюю точку
            coords.append(tuple(line_coords[-1]))
        
        # Удаляем дубликаты
        return np.array(list(dict.fromkeys(coords)))

    def create_centerline_voronoi(self, polygon, density):
        """Создание centerline через Voronoi диаграмму (метод HCMGIS)"""
        try:
            # Дискретизация
            points = self.densify_boundary(polygon, density)
            
            if len(points) < 4:
                return None
            
            # Voronoi диаграмма
            vor = Voronoi(points)
            
            # Фильтрация ребер
            centerline_segments = []
            for ridge_vertices in vor.ridge_vertices:
                if -1 not in ridge_vertices:
                    p1 = vor.vertices[ridge_vertices[0]]
                    p2 = vor.vertices[ridge_vertices[1]]
                    
                    # Проверка на принадлежность полигону
                    mid_point = Point((p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2)
                    if polygon.contains(Point(p1)) and polygon.contains(Point(p2)):
                        centerline_segments.append(LineString([p1, p2]))
            
            if not centerline_segments:
                return None
            
            # Объединение сегментов
            merged = linemerge(centerline_segments)
            
            return merged
            
        except Exception as e:
            raise QgsProcessingException(f'Ошибка Voronoi: {str(e)}')

    def split_at_junctions(self, geom):
        """Разделение линий в точках пересечения"""
        if geom.geom_type == 'LineString':
            return [geom]
        elif geom.geom_type == 'MultiLineString':
            # Используем unary_union для разделения в точках касания
            lines = list(geom.geoms)
            union = unary_union(lines)
            if union.geom_type == 'LineString':
                return [union]
            else:
                return list(union.geoms)
        return [geom]

    def processAlgorithm(self, parameters, context, feedback):
        source = self.parameterAsSource(parameters, self.INPUT, context)
        density = self.parameterAsDouble(parameters, self.DENSITY, context)
        simplify = self.parameterAsDouble(parameters, self.SIMPLIFY, context)
        connect = self.parameterAsBoolean(parameters, self.CONNECT_FEATURES, context)
        split = self.parameterAsBoolean(parameters, self.SPLIT_AT_JUNCTIONS, context)

        if source is None:
            raise QgsProcessingException(self.invalidSourceError(parameters, self.INPUT))

        # Создание полей выходного слоя
        fields = QgsFields()
        fields.append(QgsField('fid_source', QVariant.Int))
        fields.append(QgsField('length_m', QVariant.Double))
        
        # Копируем поля из источника
        for field in source.fields():
            fields.append(field)

        (sink, dest_id) = self.parameterAsSink(
            parameters,
            self.OUTPUT,
            context,
            fields,
            QgsWkbTypes.LineString,
            source.sourceCrs()
        )

        if sink is None:
            raise QgsProcessingException(self.invalidSinkError(parameters, self.OUTPUT))

        total = source.featureCount()
        
        # Предварительная обработка: объединение касающихся полигонов
        if connect:
            feedback.pushInfo('Объединение касающихся полигонов...')
            dissolved = processing.run("native:dissolve", {
                'INPUT': parameters[self.INPUT],
                'FIELD': [],
                'OUTPUT': 'memory:'
            }, context=context, feedback=feedback)
            
            features = dissolved['OUTPUT'].getFeatures()
        else:
            features = source.getFeatures()

        # Обработка
        for current, feature in enumerate(features):
            if feedback.isCanceled():
                break

            geom = feature.geometry()
            
            if geom.isEmpty() or geom.isNull():
                feedback.pushWarning(f'Объект {feature.id()}: пустая геометрия')
                continue

            try:
                # Конвертация в Shapely
                shapely_geom = wkt.loads(geom.asWkt())
                
                if shapely_geom.geom_type == 'Polygon':
                    polygons = [shapely_geom]
                elif shapely_geom.geom_type == 'MultiPolygon':
                    polygons = list(shapely_geom.geoms)
                else:
                    continue

                all_lines = []
                
                for poly in polygons:
                    # Создание centerline
                    centerline = self.create_centerline_voronoi(poly, density)
                    
                    if centerline is None:
                        continue
                    
                    # Упрощение
                    if simplify > 0:
                        centerline = centerline.simplify(
                            simplify, 
                            preserve_topology=True
                        )
                    
                    # Разделение на сегменты
                    if split:
                        lines = self.split_at_junctions(centerline)
                    else:
                        if centerline.geom_type == 'LineString':
                            lines = [centerline]
                        else:
                            lines = list(centerline.geoms)
                    
                    all_lines.extend(lines)

                # Создание выходных объектов
                for line in all_lines:
                    if line.length > 0:
                        qgs_geom = QgsGeometry.fromWkt(line.wkt)
                        
                        out_feature = QgsFeature()
                        out_feature.setGeometry(qgs_geom)
                        
                        # Атрибуты
                        attrs = [feature.id(), line.length] + feature.attributes()
                        out_feature.setAttributes(attrs)
                        
                        sink.addFeature(out_feature, QgsFeatureSink.FastInsert)

            except Exception as e:
                feedback.pushWarning(f'Объект {feature.id()}: {str(e)}')
                import traceback
                feedback.pushInfo(traceback.format_exc())

            feedback.setProgress(int(current * 100 / total))

        return {self.OUTPUT: dest_id}