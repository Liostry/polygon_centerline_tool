from qgis.core import QgsProcessingProvider
from PyQt5.QtGui import QIcon
import os
from .polygon_centerline_algorithm import PolygonCenterlineAlgorithm

class PolygonCenterlineProvider(QgsProcessingProvider):

    def __init__(self):
        QgsProcessingProvider.__init__(self)

    def unload(self):
        pass

    def loadAlgorithms(self):
        self.addAlgorithm(PolygonCenterlineAlgorithm())

    def id(self):
        return 'polygoncenterline'

    def name(self):
        return self.tr('Polygon Centerline')

    def icon(self):
        return QIcon(os.path.join(os.path.dirname(__file__), 'icon.png'))

    def longName(self):
        return self.name()